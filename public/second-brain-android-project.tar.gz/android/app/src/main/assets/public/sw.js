/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "9fa44e7b7f9a8aadcf553199368c5ebc"
  }, {
    "url": "pwa-512x512.png",
    "revision": "9fa44e7b7f9a8aadcf553199368c5ebc"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b3c9d55e6f9a3562147b788c8267a80b"
  }, {
    "url": "index.html",
    "revision": "9b8c2ef426f79c7ebdbcf2c06d61c6a4"
  }, {
    "url": "icon.svg",
    "revision": "8cc2f6bfb2ab4f92c77fbc3342fbb41f"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "46a0f812fc42dfccbce13be02a9c1e47"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-oJQooG8W.js",
    "revision": null
  }, {
    "url": "assets/index-D0Ep_GKX.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "46a0f812fc42dfccbce13be02a9c1e47"
  }, {
    "url": "icon.svg",
    "revision": "8cc2f6bfb2ab4f92c77fbc3342fbb41f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b3c9d55e6f9a3562147b788c8267a80b"
  }, {
    "url": "pwa-512x512.png",
    "revision": "9fa44e7b7f9a8aadcf553199368c5ebc"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "9fa44e7b7f9a8aadcf553199368c5ebc"
  }, {
    "url": "manifest.webmanifest",
    "revision": "6494125fe701309418cda24eb3c93c7e"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
